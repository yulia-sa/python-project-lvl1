#!/usr/bin/env python

import prompt
from random import randint


WELCOME_MESSAGE = "Welcome to the Brain Games!"
GAME_RULES = "Answer \"yes\" if the number is even, otherwise answer \"no\"."

NUMBERS_LEFT_BOUNDARY = 0
NUMBERS_RIGHT_BOUNDARY = 0

ROUND_NUMBER = 3


def welcome_user():
    name = prompt.string("May I have your name? ")
    return name


def guess_the_number():
    return randint(NUMBERS_LEFT_BOUNDARY, NUMBERS_RIGHT_BOUNDARY)


def is_even(number):
    return "yes" if number % 2 == 0 else "no"


def game_even():
    print(WELCOME_MESSAGE)
    user_name = welcome_user()
    print(f"Hello, {user_name}!")
    print(GAME_RULES)

    i = 0
    while i < ROUND_NUMBER:
        guessed_number = guess_the_number()
        print("Question: " + str(guessed_number))
        user_number = input("Your answer: ")
        right_answer = is_even(guessed_number)
        if not user_number.lower() == right_answer:
            print(f"'{user_number.lower()}' is wrong answer ;(. Correct answer was '{right_answer}'.")
            print(f"Let's try again, {user_name}!")           
            break
        print("Correct!")
        i +=1

        print(f"Congratulations, {user_name}!") # TODO вынести, чтобы выводилось только после 3-х раундов!


if __name__ == '__main__':
    game_even()




'''
В случае, если пользователь даст неверный ответ, необходимо завершить игру и вывести сообщение:

'yes' is wrong answer ;(. Correct answer was 'no'.
Let's try again, Bill!
В случае, если пользователь ввел верный ответ, нужно отобразить:

Correct!
и приступить к следующему числу.

Пользователь должен дать правильный ответ на три вопроса подряд. После успешной игры нужно вывести:

Congratulations, Bill!
'''



'''
Welcome to the Brain Games!
May I have your name? Sam
Hello, Sam!
Answer "yes" if the number is even, otherwise answer "no".
Question: 15
Your answer: no
Correct!
Question: 6
Your answer: yes
Correct!
Question: 7
Your answer: no
Correct!
Congratulations, Sam!
'''